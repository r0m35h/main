<h1 align='center'>✯ JɪᴏTV Pʟᴀʏ ✯</h1>

<!-- DO NOT EDIT FILE AND ADD YOU NAME HERE AND PUBLISH -->
<!-- © 2021 AvishkarPatil -->

<h4 align='center'>📺 The PHP Script For Grabb Streaming Links and Play it , This Workes Only on Indian Server and LocalHost [ VPS ] due to Geo-restrictions<br><br>🌟 Start This Repositry Befor Copying 😎<br>angry Don't Remove Credits
Don't Edit This Script smiling_imp
<br><br>Put Your Own SsoToken and Other Details In This Script</h4>
<br>


<h2>😇 Features :</h2>

- *HQ Streaming* <br>
- *Web Play Supports*
- *TiviMate or PC Users can Also Use This*<br>

 <br>

<h2>🍁 How To Use : </h2>

#### ♢ For Mobiles / TV :


• Download KSWEB PRO From Here :

```py
 https://s3.dlandroid.com/apps/KSWEB-server[dlandroid.com].apk

```

• Download this ZIP File From [Here](https://github.com/avipatilpro/JioTV/blob/main/token.php)<br>
• Extract in the on Mobile in htdocs Folder <br>
• Start Localhost Server and Go To localhost:8080/login.php <br>
• Put Jio Login Details and Submit <br>
• Go Back To Home and Enjoy !<br><br>

#### ♢ For PC / Laptop :

• Download XAMPP From Here<br>

```py
https://www.apachefriends.org/index.html

```
• Download Given ZIP and Extract in htdocs Folder<br>
• Open localhost/login.php <br>
• Put Jio Login Details and Submit <br>
• Go Back To Home and Enjoy !


```py
[+] - You Can Also Host on Indian Server or VPS as you want .

```
<br>

#### ♢ Playlist :

• For Playlist Host This Files and Use Following

  ```py
  [+] - http://localhost:8080/JioTV/playlist.php
  [+] - https://example.com/JioTV/playlist.php
  
  ```
<br><br>

<h4>🚸 This is Just For Educational Purpose and Entertainment !</h4>
<br>

<h3>🤗 Meet Me : </h3>

• 😪 Check you did all This Perfectly Before Messaging [ Warning ] <br>
• For any Support About Script contact [@AvishkarPatil](https://telegram.me/AvishkarPatil)  at Telegram <br>
• Or Contact at [proavipatil@gmail.com](mailto:proavipatil@gmail.com)

<br>


---
<h4 align='center'>© 2022 Aνιѕнкαя Pαтιℓ</h4>

<!-- DO NOT REMOVE THIS CREDIT 🤬 🤬 -->

